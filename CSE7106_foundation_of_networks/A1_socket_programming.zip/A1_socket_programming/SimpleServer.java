import java.net.*;
import java.io.*;

public class SimpleServer{
	public static void main(String args[]) throws IOException {
		ServerSocket s= new ServerSocket(8080);
		System.out.println("Server waiting for connection.....");
		Socket s1= s.accept();
		System.out.println("connection established....\n");
		
		DataInputStream is =  new DataInputStream(s1.getInputStream());
		DataOutputStream os =  new DataOutputStream(s1.getOutputStream());
		
		String st = new String(is.readUTF());
		
		
		if (st.equals("ping")){
			System.out.println("Server received: "+st);
			System.out.println("Server sending back: pong");
			os.writeUTF("pong");
		}
		else{
			System.out.println("Server received:"+st);
			System.out.println("not understood");
		}

		os.close();
		s1.close();
		s1.close();
		}
}
		



