import java.net.*;
import java.io.*;

public class SimpleClient{
	public static void main(String args[]) throws IOException {
		Socket s1 = new Socket("localhost",8080);
		
		DataInputStream is =  new DataInputStream(s1.getInputStream());
		DataOutputStream os =  new DataOutputStream(s1.getOutputStream());
		String message_send="ping";
		System.out.println("Client sent:"+message_send);
		os.writeUTF(message_send);
		String message_received = new String(is.readUTF());
		System.out.println("Client received:"+message_received);
		
		os.close();
		s1.close();
	}
}
