#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#include <sys/types.h>
#include <unistd.h>

#define N 20000000
#define k 10

long long sum = 0;
struct ithread
{
    int tn;
    int start;
    int end;
};

pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

void* sumfunc(void *arg)
{
    int i;
    struct ithread *thread_struct = (struct ithread*)arg;



    for(i=thread_struct->start;i<=thread_struct->end;i++)
    {   pthread_mutex_lock(&mutex);

        sum += i;

        pthread_mutex_unlock(&mutex);
    }
    printf("Thread %d sums to be %lld\n",thread_struct->tn,sum);
    pthread_exit(NULL);
}


int main(int argc, char *argv[]){
    int i;

    struct ithread t[k];

    for(i=0;i<k;i++)
        {

            t[i].tn = i;
        }

    if (N%k == 0)
    {
        for(i=0;i<k;i++)
        {
           t[i].start = i*N/k+1;
           t[i].end = (i+1)*N/k;
        }

    }
    else
    {
        for(i=0;i<k-1;i++)
        {
           t[i].start = i*N/k+1;
           t[i].end = (i+1)*N/k;
        }
            t[k-1].start = N-(N/k+N%k);
            t[k-1].end = N;
    }

    pthread_t tid[k];
    for(int i=0;i<k;i++)
    {
        pthread_attr_t attr;
        pthread_attr_init(&attr);
        pthread_create(&tid[i],&attr,sumfunc,&t[i]);
    }

        for(int i=0;i<k;i++)
    {
        pthread_join(tid[i],NULL);

    }
    printf("The sum of all threads is: %lld\n",sum);
    return 0;
}

