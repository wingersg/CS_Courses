import random
import time

def main():
    random.seed(0)
    n = int(input("Enter the array size:"))
    list = random.sample(xrange(n), n)
    print 'before sorting the array is:', list
    t0 = time.time()
    print 'bubble sorting the array is:', bubbleSort(list)
    t1 = time.time()
    print 'merge sorting the array is:', mergeSort(list)
    t2 = time.time()
    print 'bubble sorting time for ',n,'array is:',t1-t0
    print 'merge sorting time for ',n,'array is', t2-t1

# define the bubble sort function
def bubbleSort(list):
    for num in range(len(list)-1,0,-1):
        for i in range(num):
            if list[i] > list[i+1]:
                temp = list[i]
                list[i] = list[i+1]
                list[i+1] = temp
    return list

# define the merge sort function
def mergeSort(list):
    if len(list)>1:
        # split the list into half
        mid = len(list)//2
        L = list[:mid]
        R = list[mid:]
        # recursively sort the left half and right half
        mergeSort(L)
        mergeSort(R)

        i=0
        j=0
        k=0
        # obtain the min of left or right half and put them in a list
        while i < len(L) and j < len(R):
            if L[i] < R[j]:
                list[k] = L[i]
                i = i+1
            else:
                list[k] = R[j]
                j = j+1
            k=k+1
        # put the smallest numbers one by one back to left half
        while i < len(L):
            list[k] = L[i]
            i = i+1
            k = k+1
        # put the smallest numbers one by one back to the right half
        while j < len(R):
            list[k] = R[j]
            j = j+1
            k = k+1
    return list

if __name__ == "__main__":
    main()



