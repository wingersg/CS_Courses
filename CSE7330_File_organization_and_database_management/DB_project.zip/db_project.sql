drop database OSF;
create database OSF;
use OSF;

create table Employees(
ID int(5) PRIMARY KEY,
Name varchar(60) not null,
HireDate date not null,
Mgr varchar(255)
);

insert into Employees values
(10100,'Employee-1','1984-11-08',null),
(10200,'Employee-2','1994-11-08',10100),
(10300,'Employee-3','2004-11-08',10200),
(10400,'Employee-4','2008-11-01',10200),
(10500,'Employee-5','2015-11-01',10400),
(10600,'Employee-6','2015-11-01',10400),
(10700,'Employee-7','2016-11-01',10400),
(10800,'Employee-8','2017-11-01',10200);

#select * from Employees;

#drop table Components;

create table Components(
BuildID int(255) auto_increment,
component_name varchar(255), 
version char(3),
size int,
language varchar(255),
owner int(5),
primary key(BuildID,component_name,version),
foreign key(owner) references Employees(ID)
);
ALTER TABLE Components AUTO_INCREMENT=1;

insert into Components(component_name,version,size,language,owner)
values
('Keyboard_Driver','K11',1200,'C',10100),
('Touch_Screen_Driver','T00',4000,'C++',10100),
('Dbase_Interface','D00',2500,'C++',10200),
('Dbase_Interface','D01',2500,'C++',10300),
('Chart_generator','C11',6500,'Java',10200),
('Pen_driver','P01',3575,'C',10700),
('Math_unit','A01',5000,'C',10200),
('Math_unit','A02',3500,'Java',10200);

#select * from Components;

#create a trigger for new component also inserted into Inspection table
delimiter //
create trigger insert_component_to_Inspection
after insert on Components
for each row
begin
	insert into Inspections(InspectID,component_name,version)
	values(new.BuildID,new.component_name,new.version);
end;
//

create table Software_Products
(name varchar(255) not null,
version varchar(255) not null,
status varchar(255),
PRIMARY KEY(name,version)
);

insert into  Software_Products(name,version) values
('Excel','2010'),
('Excel','2015'),
('Excel','2018beta'),
('Excel','secret');

drop table Products;

create table Products
(name varchar(255),
version varchar(255),
components int(255),
foreign key(components) references Components(BuildID),
foreign key(name,version) references Software_Products(name,version)
);

insert into  Products(name,version,components) values
('Excel','2010',1),
('Excel','2010',3),
('Excel','2015',1),
('Excel','2015',4),
('Excel','2015',6),
('Excel','2018beta',1),
('Excel','2018beta',2),
('Excel','2018beta',5),
('Excel','secret',1),
('Excel','secret',2),
('Excel','secret',5),
('Excel','secret',8);

select * from Products;

#drop table inspections;

create table Inspections(
InspectID int,
component_name varchar(255), 
version char(3),
inspection_date date ,
by_who int(5),
score int(3),
description varchar(4000),
status varchar(255),
foreign key(by_who) references Employees(ID),
foreign key(InspectID,component_name,version) references Components(BuildID,component_name,version)
);

/*trigger to get the status for insert */
delimiter //
create trigger insert_status
before insert on Inspections
for each row
begin
    if (new.score>=90) then
		set new.status='Ready';
	elseif (new.score<90 and new.score>=75) then
		set new.status='usable';
    else
		set new.status='not-ready';
end if;
end;
//


# trigger to get the status for update
delimiter //
create trigger update_status
before update on Inspections
for each row
begin
    if (new.score>=90) then
		set new.status='Ready';
	elseif (new.score<90 and new.score>=75) then
		set new.status='usable';
    else
		set new.status='not-ready';
end if;
end;
//

#drop trigger update_status;

/*trigger to update the InspectID*/
delimiter //
create trigger update_InspectID
before insert on Inspections
for each row
begin
	set new.InspectID=(select BuildID from Components where new.component_name=Components.component_name and new.version=Components.version);
end;
//

#drop trigger update_InspectID; 
#show triggers;

insert into Inspections(component_name,version,inspection_date,by_who,score,description)
values
('Keyboard_Driver','K11','2010-02-14',10100,100,'legacy code which is already approved'),
('Touch_Screen_Driver','T00','2017-06-01',10200,95,'initial release ready for usage'),
('Dbase_Interface','D00','2010-02-22',10100,55,'too many hard coded paramenters,the software must be more maintainable and configurable because we want to use this in other products'),
('Dbase_Interface','D00','2010-02-24',10100,78,'improved, but only handles DB2 format'),
('Dbase_Interface','D00','2010-02-26',10100,95,'Okay, handles DB3 format.'),
('Dbase_Interface','D00','2010-02-28',10100,100,'satisfied'),
('Dbase_Interface','D01','2011-05-01',10200,100,'Okay ready for use'),
('Chart_generator','C11',null,null,null,null),
('Pen_driver','P01','2017-07-15',10300,80,'Okay ready for beta testing'),
('Math_unit','A01','2014-06-10',10100,90,'almost ready'),
('Math_unit','A02','2014-06-15',10100,70,'Accuracy problems!'),
('Math_unit','A02','2014-06-30',10100,100,'Okay problems fixed'),
('Math_unit','A02','2016-11-02',10700,100,'re-review for new employee to gain experience in the process.');

#delete from Inspections;


select * from Inspections;
select * from Components;

create table Programming_languages(
Current varchar(255),
Future varchar(255)
);

insert into Programming_languages values
('Current','C'),
('Current','C++'),
('Current','C#'),
('Current','Java'),
('Current','PHP'),
('Future','Python'),
('Future','assembly');


/*show all tables*/
select * from Employees;
select * from Components;
select * from Software_Products;
select * from Products;
select * from Inspections;
select * from Programming_languages;


describe Employees;
describe Components;
describe Software_Products;
describe Products;
describe Inspections;
describe Programming_languages;


/*
1. seniority
2. scores range
3.mgr id must be a valid id, representing the person's manager. The exception is employee 10100 (the CEO) who can have a null mgr id.
4.Seniority is based on a 365 day year, computed when the data is queried.
5.Inspection descriptions have a maximum of 4000 characters.
6.If a component has not been inspected, it has a status of 'not-ready'.
7. ID:5 character, name: 60
8.inspection score(0~100)
9. status
*/

alter table Employees
add column seniority varchar(255) after Mgr;

update Employees
set seniority = 'newbie'
where  (SELECT DATEDIFF(now(), HireDate))<365;

update Employees
set seniority = 'junior'
where (SELECT DATEDIFF(now(), HireDate))>365 and (SELECT DATEDIFF("2017-11-15", HireDate))<1825;

update Employees
set seniority = 'senior'
where (SELECT DATEDIFF(now(), HireDate))>1825;

alter table Inspections
add column status varchar(255) after description;

update Inspections
set status = "Ready"
where score>=90;

update Inspections
set status = "not-ready"
where score<=75 or inspection_date is null;

update Inspections
set status = "usable"
where score>75 and score<90;

select * from Inspections;

drop table status_view;
create table status_view as
(
SELECT InspectID as component,status,score
from Inspections
where score in (select distinct max(score) from Inspections group by InspectID) or score is null
group by InspectID);

create table Excel2018beta as
(select * from Products where name='Excel' and version='2018beta'
);

select status_view.component,status_view.score,status_view.status
from status_view
inner join Excel2018beta
on status_view.component=Excel2018beta.components
order by score limit 1;


select * from Products;


select * from Components;
alter table Components
add column status varchar(255) after owner;

update Components,status_view
set Components.status= status_view.status
where Components.BuildID = status_view.InspectID;

update Components
set status = "not-ready"
where status is null;

select * from Products;
alter table Products
add column status varchar(255) after components;

update Products,status_view
set Products.status= status_view.status
where Products.components = status_view.InspectID;

update Products
set status = "not-ready"
where status is null;

select * from Products;

select name,version,status
from Products
where status != 'Ready' 
group by name,version;

alter table Software_Products
add column status varchar(255) after version;

alter table Software_Products
drop column status;

update Software_Products,Products
set Software_Products.status = Products.status
where Products.status!='Ready';

select * from Products;

drop table t1;
create table t1 as(
select name,version,count(status) as cs,status
from Products
where status!= 'Ready'
group by name,version
having cs>=1);

create table t2 as(select name,version,count(status) as cs,status
from Products
where status = 'Ready'
group by name,version);

select * from t1;
select * from t2;

SET SQL_SAFE_UPDATES = 0;

select * from Software_Products;



delimiter //
create trigger protect_score 
before update on Inspections
for each row
begin
    if new.score != score then
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT="PROHIBITED TO CHANGE SCORES!";
end if;
end
//
drop trigger protect_score;

UPDATE Inspections
SET score = 65 
where inspection_date='2010-02-22';



delimiter //
create trigger seniority_insert 
before insert on Employees
for each row
begin
    if (datediff(now(),new.Hiredate)<=365) then
    set new.seniority = 'newbie';
    elseif (datediff(now(),new.Hiredate))>=1825 then
    set new.seniority = 'senior';
    else 
    set new.seniority = 'junior';
	end if;
end//

drop trigger seniority_insert;

delimiter //
create trigger check_score 
after insert on Inspections
for each row
begin
    if (new.score<0 or new.score>100) then
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT="incorrect score!";
	end if;
end//


delimiter //
create trigger update_status
before insert on Inspections
for each row
begin
    if (new.score>=90) then
    insert into Inspections(score,status) values(new.score,'Ready');
    elseif (score<=75) then
    insert into Inspections(score,status) values(new.score,'not-ready');
    else 
    insert into Inspections(score,status) values(new.score,'usable');
	end if;
end//

drop trigger update_status;
show triggers;


select * from Components;

select * from products;

select * from Software_Products;



create table t4 as(select name,version from products
where status in("not-ready")
group by name,version);
select * from t4;


create table t5 as(select name,version from products
where status in("usable")
group by name,version);
select * from t5;

update Software_Products
set status='not-ready'
where version in (select version from t4);

update Software_Products
set status='usable'
where version in (select version from t5) and version not in (select version from t4);

update Software_Products
set status='ready'
where version not in (select version from t4) and version not in(select version from t5);

select * from Software_Products;

/*List the owner name, component name & version of all “not ready” components. */

select Employees.Name as owner_name, Components.component_name,Components.version
from Employees
inner join Components
on Employees.ID = Components.owner
where Components.status in ("not-ready");

select * from Inspections;
select * from Components;
select * from products;

select Components.component_name,Components.version
from Components 
inner join Inspections
on Inspections.InspectID=Components.BuildID
where Inspections.score is null;


select sum(((select count(distinct component_name) from Components) / (select count(distinct owner) from Components)) ) as average;


select avg(score) as average from (
select Inspections.InspectID,Inspections.score
from Inspections
inner join products
on Inspections.InspectID=products.components
where score is not null) A;

/*List all employees by name, seniority, count of components assigned to them, 
count of inspections performed by them and their average inspection score. */

select * from Employees;
select * from Components;
select * from Inspections;

drop table t6;
drop table t7;

create table t6 as(select Employees.ID,Employees.Name,Employees.seniority,count(Components.component_name) as numOfComp
from Employees
inner join Components
on Employees.ID=Components.owner
group by Employees.ID);

select * from t6;


create table t7 as(select Inspections.by_who,count(Inspections.by_who) as countInspect, avg(Inspections.score) as avgScore
from Inspections
where Inspections.score is not null
group by by_who);

select * from t7;

select t6.Name,t6.seniority,t6.numOfComp,t7.countInspect,t7.avgScore
from t6
inner join t7
on t6.ID=t7.by_who;

/*7.Assume an inspection that results in a “ready” status costs $200, and all other inspections cost $100 each. 
How much did OSF in 2010 for inspections conducted by each seniority level?
*/
select * from Inspections;

select * 
from Inspections
where inspection_date like "2010%";

select * from t9;
drop table t9;

create table t9 as(
select Inspections.by_who,Inspections.status 
from Inspections
inner join Employees
on Inspections.by_who=Employees.ID
where year(inspection_date)="2010");


select * from t9;

select by_who,count(*) from t9
where status="Ready"
group by by_who;

select by_who,count(*) from t9
where status!="Ready"
group by by_who;


select sum(
(select 200*count(*) as ready_cost
from t9
where status ="Ready")
+
(select 100*count(*) as non_ready_cost
from t9
where status !="Ready")
) as cost
from t9
group by by_who;


/* 8.Demonstrate the adding of a new inspection by employee 10400 on Pen driver - 
P01 held on 8/15/2017 with the score of 60 and description of “needs rework, introduced new errors”. */
select * from Inspections;
select * from Components;
show triggers;

drop trigger update_status;

drop trigger update_InspectID;


select * from Inspections;
delete from Inspections;

select * from Inspections;

insert into Inspections(component_name,version,inspection_date,by_who,score,description) 
values ('Pen_driver','P01','2017-08-15',10400,60,'needs rework, introduced new errors');


/*Demonstrate adding a new component to Excel 2018beta. This new component is named “Dynamic Table Interface”, version D01, 
and was written in javascript by person 10400, size = 775.  */

select * from Components;

delete from Components where BuildID=9;

insert into Components(component_name,version,size,language,owner)
values('Dynamic Table Interface','D01',775,'javascript',10400);

delete from Components where component_name='Dynamic Table Interface';
show triggers;


#create a trigger for new component also inserted into Inspection table
delimiter //
create trigger insert_component_to_Inspection
after insert on Components
for each row
begin
	insert into Inspections(InspectID,component_name,version)
	values(new.BuildID,new.component_name,new.version);
end;
//

delete from Components where version='W01';

select * from Components;
select * from Inspections;
insert into Products values
('Excel','2018beta',(select BuildID from Components where component_name='Dynamic Table Interface' and version='D01'));


/*Demonstrate the adding of an inspection on the component you just added. This inspection occurred on 
11/20/2017 by inspector 10500, with a score of 80, and note of “minor fixes needed”. */

update Inspections
set inspection_date = '2017-11-20',by_who=10500,score=80,description='minor fixes needed'
where component_name ='Dynamic Table Interface' and version='D01';


 










